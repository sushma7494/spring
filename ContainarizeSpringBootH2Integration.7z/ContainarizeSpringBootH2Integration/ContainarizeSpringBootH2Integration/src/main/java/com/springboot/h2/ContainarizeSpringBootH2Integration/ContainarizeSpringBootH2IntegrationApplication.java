package com.springboot.h2.ContainarizeSpringBootH2Integration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContainarizeSpringBootH2IntegrationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContainarizeSpringBootH2IntegrationApplication.class, args);
	}

}
